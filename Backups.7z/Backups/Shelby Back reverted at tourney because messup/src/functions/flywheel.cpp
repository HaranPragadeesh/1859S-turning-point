#include "main.h"
#include "../v5setup.hpp"

void fly(int voltage)
{
  flyWheel1.move(voltage);
  flyWheel2.move(voltage);
}
