#include "main.h"

void testauto();

void redclose();

void blueclose();

void redfar();

void bluefar();

void skills12();
void skills19();
