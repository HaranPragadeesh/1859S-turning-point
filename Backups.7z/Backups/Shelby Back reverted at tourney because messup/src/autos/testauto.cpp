#include "main.h"
#include "../v5setup.hpp"

void testauto()
{
    left(300);
    right(300);
}
